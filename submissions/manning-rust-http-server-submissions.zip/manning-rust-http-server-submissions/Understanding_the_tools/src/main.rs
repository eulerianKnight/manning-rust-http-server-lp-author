fn main() {
  let s : &str = "Hello UMET";
  println!("{}", s);
}